from getweather.weather import getWeather
from configurations import config
